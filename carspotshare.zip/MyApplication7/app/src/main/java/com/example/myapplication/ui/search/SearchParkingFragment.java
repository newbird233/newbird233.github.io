package com.example.myapplication.ui.search;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.myapplication.ParkingInfo;
import com.example.myapplication.ParkingInfoAdapter;
import com.example.myapplication.ParkingInfoDataManager;
import com.example.myapplication.R;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class SearchParkingFragment extends Fragment {

    private EditText etResidenceSearch, etDateSearch, etStartTimeSearch;
    private Button btnSearch,btnOccupy;
    private RecyclerView recyclerViewSearchResult;
    private ParkingInfoAdapter parkingInfoAdapter;
    private List<ParkingInfo> searchResultList;

    private ParkingInfoDataManager parkingInfoDataManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        etResidenceSearch = view.findViewById(R.id.etResidenceSearch);
        etDateSearch = view.findViewById(R.id.etDateSearch);
        etStartTimeSearch = view.findViewById(R.id.etStartTimeSearch);
        btnSearch = view.findViewById(R.id.btnSearch);
        recyclerViewSearchResult = view.findViewById(R.id.recyclerViewSearchResult);

        parkingInfoDataManager = new ParkingInfoDataManager(requireContext());
        parkingInfoDataManager.open();

        searchResultList = new ArrayList<>();
        parkingInfoAdapter = new ParkingInfoAdapter(searchResultList);
        recyclerViewSearchResult.setLayoutManager(new LinearLayoutManager(requireContext()));
        recyclerViewSearchResult.setAdapter(parkingInfoAdapter);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 处理车位信息搜索逻辑
                String residence = etResidenceSearch.getText().toString();
                String date = etDateSearch.getText().toString();
                String startTime = etStartTimeSearch.getText().toString();
                searchResultList.clear();
                searchResultList.addAll(parkingInfoDataManager.searchParkingInfo(residence, date, startTime));
                parkingInfoAdapter.notifyDataSetChanged();
            }
        });

        return view;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        parkingInfoDataManager.close();
    }
}