package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private EditText etUsername, etPassword, etResidence, etParkingNumber, etPhoneNumber;
    private Button btnRegister;
    private UserDataManager userDataManager;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        etResidence = findViewById(R.id.etResidence);
        etParkingNumber = findViewById(R.id.etParkingNumber);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        btnRegister = findViewById(R.id.btnRegister);

    }
    public void registerUser(View view) {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String residence = etResidence.getText().toString().trim();
        String parkingNumber = etParkingNumber.getText().toString().trim();
        String phoneNumber = etPhoneNumber.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty() || residence.isEmpty() || parkingNumber.isEmpty() || phoneNumber.isEmpty()) {
            Toast.makeText(this, "填写必选项", Toast.LENGTH_SHORT).show();
            return;
        }

        databaseHelper.addUser(username, password, residence, parkingNumber, phoneNumber);
        Toast.makeText(this, "注册成功", Toast.LENGTH_SHORT).show();


        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        userDataManager.close();
    }
}