package com.example.myapplication.ui.publish;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.myapplication.ParkingInfo;
import com.example.myapplication.ParkingInfoAdapter;
import com.example.myapplication.ParkingInfoDataManager;
import com.example.myapplication.R;

import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class PublishParkingFragment extends Fragment {

    private EditText etDate, etStartTime, etEndTime;
    private Button btnPublish, btnCancel;
    private RecyclerView recyclerView;
    private ParkingInfoAdapter ParkingInfoAdapter;
    private List<ParkingInfo> parkingInfoList;

    private ParkingInfoDataManager parkingInfoDataManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_publish, container, false);

        etDate = view.findViewById(R.id.etDate);
        etStartTime = view.findViewById(R.id.etStartTime);
        etEndTime = view.findViewById(R.id.etEndTime);
        btnPublish = view.findViewById(R.id.btnPublish);
        btnCancel = view.findViewById(R.id.btnCancel);
        recyclerView = view.findViewById(R.id.recyclerView);

        parkingInfoDataManager = new ParkingInfoDataManager(requireContext());
        parkingInfoDataManager.open();

        parkingInfoList = new ArrayList<>();
        ParkingInfoAdapter = new ParkingInfoAdapter(parkingInfoList);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        recyclerView.setAdapter(ParkingInfoAdapter);

        btnPublish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 处理发布车位信息逻辑

                ParkingInfo parkingInfo = new ParkingInfo("test", "A", "A123", "1234567890", "2024-01-`", "09:00 AM", "05:00 PM");
                parkingInfo.setDate(etDate.getText().toString());
                parkingInfo.setStartTime(etStartTime.getText().toString());
                parkingInfo.setEndTime(etEndTime.getText().toString());

                // 设置其他信息，如用户名、小区名称、车位编号、联系电话等

                long result = parkingInfoDataManager.insertParkingInfo(parkingInfo);

                if (result != -1) {
                    parkingInfoList.add(parkingInfo);
                    ParkingInfoAdapter.notifyDataSetChanged();
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 处理取消发布逻辑
                // 可以在此处实现删除发布的车位信息等操作
            }
        });

        // 加载已发布的车位信息
        loadPublishedParkingInfo();

        return view;
    }

    private void loadPublishedParkingInfo() {
        // 从数据库中加载已发布的车位信息

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        parkingInfoDataManager.close();
    }
}