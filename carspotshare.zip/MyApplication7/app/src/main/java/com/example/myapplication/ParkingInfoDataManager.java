package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ParkingInfoDataManager {

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    public ParkingInfoDataManager(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() throws SQLException {
        db = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long insertParkingInfo(ParkingInfo parkingInfo) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.KEY_USERNAME, parkingInfo.getUsername());
        values.put(DatabaseHelper.KEY_RESIDENCE, parkingInfo.getResidence());
        values.put(DatabaseHelper.KEY_PARKING_NUMBER, parkingInfo.getParkingNumber());
        values.put(DatabaseHelper.KEY_PHONE_NUMBER, parkingInfo.getPhoneNumber());
        values.put(DatabaseHelper.KEY_DATE, parkingInfo.getDate());
        values.put(DatabaseHelper.KEY_START_TIME, parkingInfo.getStartTime());
        values.put(DatabaseHelper.KEY_END_TIME, parkingInfo.getEndTime());

        return db.insert(DatabaseHelper.TABLE_USERS, null, values);
    }

    // 查询已发布的车位信息
    public List<ParkingInfo> searchParkingInfo(String residence, String date, String startTime) {
        List<ParkingInfo> result = new ArrayList<>();

        try {
            Cursor cursor = db.query(
                    DatabaseHelper.TABLE_USERS,
                    new String[]{DatabaseHelper.KEY_USERNAME, DatabaseHelper.KEY_RESIDENCE, DatabaseHelper.KEY_PARKING_NUMBER,
                            DatabaseHelper.KEY_PHONE_NUMBER, DatabaseHelper.KEY_DATE, DatabaseHelper.KEY_START_TIME, DatabaseHelper.KEY_END_TIME},
                    DatabaseHelper.KEY_RESIDENCE + "=? AND " + DatabaseHelper.KEY_DATE + "=? AND " + DatabaseHelper.KEY_START_TIME + "=?",
                    new String[]{residence, date, startTime},
                    null, null, null, null
            );

            if (cursor != null) {
                while (cursor.moveToNext()) {
                    ParkingInfo parkingInfo = new ParkingInfo();
                    parkingInfo.setUsername(cursor.getString(cursor.getColumnIndex(DatabaseHelper.KEY_USERNAME)));
                    parkingInfo.setResidence(cursor.getString(cursor.getColumnIndex(DatabaseHelper.KEY_RESIDENCE)));
                    parkingInfo.setParkingNumber(cursor.getString(cursor.getColumnIndex(DatabaseHelper.KEY_PARKING_NUMBER)));
                    parkingInfo.setPhoneNumber(cursor.getString(cursor.getColumnIndex(DatabaseHelper.KEY_PHONE_NUMBER)));
                    parkingInfo.setDate(cursor.getString(cursor.getColumnIndex(DatabaseHelper.KEY_DATE)));
                    parkingInfo.setStartTime(cursor.getString(cursor.getColumnIndex(DatabaseHelper.KEY_START_TIME)));
                    parkingInfo.setEndTime(cursor.getString(cursor.getColumnIndex(DatabaseHelper.KEY_END_TIME)));

                    result.add(parkingInfo);
                }

                cursor.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return result;
    }
}
