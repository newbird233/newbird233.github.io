package com.example.myapplication;

public class User {
    private int id;
    private String username;
    private String password;
    private String residence;
    private String parkingNumber;
    private String phoneNumber;

    public User() {
        // 默认构造函数
    }

    public User(String username, String password, String residence, String parkingNumber, String phoneNumber) {
        this.username = username;
        this.password = password;
        this.residence = residence;
        this.parkingNumber = parkingNumber;
        this.phoneNumber = phoneNumber;
    }

    // Getter 方法
    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getResidence() {
        return residence;
    }

    public String getParkingNumber() {
        return parkingNumber;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    // Setter 方法
    public void setId(int id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setResidence(String residence) {
        this.residence = residence;
    }

    public void setParkingNumber(String parkingNumber) {
        this.parkingNumber = parkingNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}