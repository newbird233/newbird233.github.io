package com.example.myapplication.ui.profile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.myapplication.R;
import com.example.myapplication.User;
import com.example.myapplication.UserDataManager;

import androidx.annotation.Nullable;

public class ProfileFragment extends Fragment {

    private TextView tvUsername, tvResidence, tvParkingNumber, tvPhoneNumber;
    private UserDataManager userDataManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        tvUsername = view.findViewById(R.id.tvUsername);
        tvUsername.setText("test");
        tvResidence = view.findViewById(R.id.tvResidence);
        tvResidence.setText("test");
        tvParkingNumber = view.findViewById(R.id.tvParkingNumber);
        tvParkingNumber.setText("test");
        tvPhoneNumber = view.findViewById(R.id.tvPhoneNumber);
        tvPhoneNumber.setText("test");

        userDataManager = new UserDataManager(requireContext());
        userDataManager.open();

        User user = userDataManager.getUser("test");

            if (user != null) {
                tvUsername.setText(user.getUsername());
                tvResidence.setText(user.getResidence());
                tvParkingNumber.setText(user.getParkingNumber());
                tvPhoneNumber.setText(user.getPhoneNumber());
            }





        userDataManager.close();

        return view;
    }
}