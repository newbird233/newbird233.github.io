package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ParkingInfoAdapter extends RecyclerView.Adapter<ParkingInfoAdapter.ViewHolder> {

    private List<ParkingInfo> parkingInfoList;

    public ParkingInfoAdapter(List<ParkingInfo> parkingInfoList) {
        this.parkingInfoList = parkingInfoList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_parking_info, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ParkingInfo parkingInfo = parkingInfoList.get(position);

        holder.tvDate.setText("Date: " + parkingInfo.getDate());
        holder.tvStartTime.setText("Start Time: " + parkingInfo.getStartTime());
        holder.tvEndTime.setText("End Time: " + parkingInfo.getEndTime());

        // 其他信息的显示
    }

    @Override
    public int getItemCount() {
        return parkingInfoList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private TextView tvDate, tvStartTime, tvEndTime;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvStartTime = itemView.findViewById(R.id.tvStartTime);
            tvEndTime = itemView.findViewById(R.id.tvEndTime);
        }
    }
}
