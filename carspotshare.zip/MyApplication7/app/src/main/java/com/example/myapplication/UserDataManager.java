package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class UserDataManager {

    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;


    public UserDataManager(Context context) {
        dbHelper = new DatabaseHelper(context);

    }

    public void open() throws SQLException {
        db = dbHelper.getWritableDatabase();
        dbHelper.upgradeDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long insertUser(User user) {

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.KEY_USERNAME, user.getUsername());
        values.put(DatabaseHelper.KEY_PASSWORD, user.getPassword());
        values.put(DatabaseHelper.KEY_RESIDENCE, user.getResidence());
        values.put(DatabaseHelper.KEY_PARKING_NUMBER, user.getParkingNumber());
        values.put(DatabaseHelper.KEY_PHONE_NUMBER, user.getPhoneNumber());

        return db.insert(DatabaseHelper.TABLE_USERS, null, values);
    }

    public User getUser(String username) {
        User user = null;
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_USERS,
                new String[]{DatabaseHelper.KEY_USERNAME, DatabaseHelper.KEY_RESIDENCE, DatabaseHelper.KEY_PARKING_NUMBER, DatabaseHelper.KEY_PHONE_NUMBER},
                DatabaseHelper.KEY_USERNAME + "=?",
                new String[]{username},
                null, null, null, null
        );

        if (cursor != null && cursor.moveToFirst()) {
            user = new User();
            user.setUsername(cursor.getString(cursor.getColumnIndex(DatabaseHelper.KEY_USERNAME)));
            user.setResidence(cursor.getString(cursor.getColumnIndex(DatabaseHelper.KEY_RESIDENCE)));
            user.setParkingNumber(cursor.getString(cursor.getColumnIndex(DatabaseHelper.KEY_PARKING_NUMBER)));
            user.setPhoneNumber(cursor.getString(cursor.getColumnIndex(DatabaseHelper.KEY_PHONE_NUMBER)));
            cursor.close();
        }

        return user;
    }
    public boolean isUserExists(String username) {
        Cursor cursor = db.query(
                DatabaseHelper.TABLE_USERS,
                new String[]{DatabaseHelper.KEY_USERNAME},
                DatabaseHelper.KEY_USERNAME + "=?",
                new String[]{username},
                null, null, null, null
        );

        boolean exists = cursor != null && cursor.getCount() > 0;
        if (cursor != null) {
            cursor.close();
        }

        return exists;
    }
}
